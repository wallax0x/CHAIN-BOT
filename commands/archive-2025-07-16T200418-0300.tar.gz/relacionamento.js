const fs = require('fs').promises;
const path = require('path');
const { PREFIX } = require('../config');

const DATA_PATH = path.resolve(__dirname, '../json/relacionamentos.json');
const TEMPO_MINIMO_CASAR = 7; // Deixado em 0 para testes. Mude para 7 se quiser.

// --- Funções Auxiliares ---
async function readData() {
    try {
        const data = await fs.readFile(DATA_PATH, 'utf8');
        return JSON.parse(data);
    } catch (error) {
        if (error.code === 'ENOENT') {
            const initialData = { casais: {}, propostas: {} };
            await writeData(initialData);
            return initialData;
        }
        return { casais: {}, propostas: {} };
    }
}

async function writeData(data) {
    await fs.writeFile(DATA_PATH, JSON.stringify(data, null, 2));
}

function findUserRelationship(userId, data) {
    for (const partner1 in data.casais) {
        const rel = data.casais[partner1];
        if (partner1 === userId || rel.partner === userId) {
            return { idPrincipal: partner1, ...rel };
        }
    }
    return null;
}

// --- LÓGICA PRINCIPAL DO COMANDO ---
const command = async (sock, m, jid, args, senderId, command) => {
    try {
        if (!jid.endsWith('@g.us')) return sock.sendMessage(jid, { text: '❌ Este comando só pode ser usado em grupos.' }, { quoted: m });

        const data = await readData();
        const botId = sock.user.id.split(':')[0] + '@s.whatsapp.net';
        const targetId = m.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0];

        // --- COMANDO DE AJUDA (.relacionamento) ---
        if (command === 'relacionamento') {
            const helpMsg = `
💞 *Sistema de Relacionamentos* 💞

*Comandos Disponíveis:*
💍 *Começar:*
  • \`${PREFIX}pedirnamoro @pessoa\`
  • \`${PREFIX}aceitar\` / \`${PREFIX}recusar\`

💖 *Evoluir:*
  • \`${PREFIX}casar\`
  • \`${PREFIX}aceitarcasamento\` / \`${PREFIX}recusarcasamento\`

💔 *Terminar:*
  • \`${PREFIX}terminarnamoro\`
  • \`${PREFIX}divorcio\`

📊 *Consultar:*
  • \`${PREFIX}statusnamoro\`
  • \`${PREFIX}casais\`
            `.trim();
            return sock.sendMessage(jid, { text: helpMsg }, { quoted: m });
        }
        
        // --- COMANDO DE STATUS (.statusnamoro) ---
        if (command === 'statusnamoro') {
            const rel = findUserRelationship(senderId, data);
            if (!rel) return sock.sendMessage(jid, { text: '💔 Você está solteiro(a) no momento.' }, { quoted: m });

            const partnerId = rel.partner === senderId ? rel.idPrincipal : rel.partner;
            const statusEmoji = rel.status === 'casado' ? '💍 Casados' : '💖 Namorando';
            const startDate = new Date(rel.startDate);
            const diasJuntos = Math.floor((Date.now() - startDate.getTime()) / (1000 * 60 * 60 * 24));
            let tempoJuntosMsg = `há ${diasJuntos} dia(s).`;
            if (diasJuntos === 0) tempoJuntosMsg = "desde hoje!";
            
            const statusMsg = `*Status do Relacionamento*\n-----------------------------------\n${statusEmoji}\n• @${senderId.split('@')[0]}\n• @${partnerId.split('@')[0]}\n\n*Juntos:* ${tempoJuntosMsg}`.trim();
            return sock.sendMessage(jid, { text: statusMsg, mentions: [senderId, partnerId] });
        }
        
        // --- LÓGICA DE PEDIR EM NAMORO ---
        if (command === 'pedirnamoro') {
            if (!targetId) return sock.sendMessage(jid, { text: `❌ Marque alguém para pedir em namoro.` }, { quoted: m });
            if (targetId === senderId) return sock.sendMessage(jid, { text: '❌ Você não pode pedir a si mesmo em namoro.' }, { quoted: m });
            if (targetId === botId) return sock.sendMessage(jid, { text: '❌ Já sou comprometido(a) com meu trabalho!' }, { quoted: m });
            if (findUserRelationship(senderId, data)) return sock.sendMessage(jid, { text: '⚠️ Você já está em um relacionamento!' }, { quoted: m });
            if (findUserRelationship(targetId, data)) return sock.sendMessage(jid, { text: `⚠️ @${targetId.split('@')[0]} já está em um relacionamento.`, mentions: [targetId] }, { quoted: m });
            
            data.propostas[targetId] = { from: senderId, type: 'namoro', timestamp: Date.now() };
            await writeData(data);
            return sock.sendMessage(jid, { text: `💖 @${senderId.split('@')[0]} pediu @${targetId.split('@')[0]} em namoro!\n\nVocê tem 60s para responder com \`${PREFIX}aceitar\` ou \`${PREFIX}recusar\`.`, mentions: [senderId, targetId] });
        }

        // --- LÓGICA DE PEDIR EM CASAMENTO ---
        if (command === 'casar') {
            const rel = findUserRelationship(senderId, data);
            if (!rel) return sock.sendMessage(jid, { text: '❌ Você precisa estar namorando para casar!' }, { quoted: m });
            if (rel.status === 'casado') return sock.sendMessage(jid, { text: '🤔 Vocês já são casados!' }, { quoted: m });

            const diasDeNamoro = (Date.now() - new Date(rel.startDate)) / (1000 * 60 * 60 * 24);
            if (diasDeNamoro < TEMPO_MINIMO_CASAR) {
                const diasFaltando = Math.ceil(TEMPO_MINIMO_CASAR - diasDeNamoro);
                return sock.sendMessage(jid, { text: `Calma! Vocês precisam de pelo menos ${TEMPO_MINIMO_CASAR} dias de namoro para casar. Faltam ${diasFaltando} dia(s).` }, { quoted: m });
            }

            const partnerId = rel.partner === senderId ? rel.idPrincipal : rel.partner;
            data.propostas[partnerId] = { from: senderId, type: 'casamento', timestamp: Date.now() };
            await writeData(data);
            return sock.sendMessage(jid, { text: `💍 @${senderId.split('@')[0]} pediu @${partnerId.split('@')[0]} em CASAMENTO!\n\nVocê tem 60s para responder com \`${PREFIX}aceitarcasamento\` ou \`${PREFIX}recusarcasamento\`.`, mentions: [senderId, partnerId] });
        }

        // --- LÓGICA PARA ACEITAR/RECUSAR ---
        if (['aceitar', 'recusar', 'aceitarcasamento', 'recusarcasamento'].includes(command)) {
            const proposta = data.propostas[senderId];
            if (!proposta || (Date.now() - proposta.timestamp > 60000)) return sock.sendMessage(jid, { text: '❌ Você não tem um pedido válido ou ele já expirou.', quoted: m });

            const pedinteId = proposta.from;
            const tipo = proposta.type;
            delete data.propostas[senderId];

            if (command === 'aceitar' && tipo === 'namoro') {
                data.casais[pedinteId] = { partner: senderId, startDate: new Date().toISOString(), status: 'namorando' };
                await sock.sendMessage(jid, { text: `🎉 Parabéns! @${pedinteId.split('@')[0]} e @${senderId.split('@')[0]} agora estão namorando!`, mentions: [pedinteId, senderId] });
            } else if (command === 'recusar' && tipo === 'namoro') {
                await sock.sendMessage(jid, { text: `💔 Que pena! @${senderId.split('@')[0]} recusou o pedido de @${pedinteId.split('@')[0]}.`, mentions: [senderId, pedinteId] });
            } else if (command === 'aceitarcasamento' && tipo === 'casamento') {
                const rel = findUserRelationship(senderId, data);
                if (rel) {
                    data.casais[rel.idPrincipal].status = 'casado';
                    data.casais[rel.idPrincipal].startDate = new Date().toISOString();
                    await sock.sendMessage(jid, { text: `🎊 FELICIDADES! @${pedinteId.split('@')[0]} e @${senderId.split('@')[0]} agora estão casados!`, mentions: [pedinteId, senderId] });
                }
            } else if (command === 'recusarcasamento' && tipo === 'casamento') {
                await sock.sendMessage(jid, { text: `😢 Noiva(o) em fuga! @${senderId.split('@')[0]} recusou o pedido de @${pedinteId.split('@')[0]}.`, mentions: [senderId, pedinteId] });
            } else {
                return sock.sendMessage(jid, { text: `❌ Comando de resposta inválido para este tipo de pedido.` }, { quoted: m });
            }
            
            await writeData(data);
            return;
        }

        // --- LÓGICA PARA TERMINAR/DIVORCIAR ---
        if (['terminar', 'divorcio', 'terminarnamoro'].includes(command)) {
            const rel = findUserRelationship(senderId, data);
            if (!rel) return sock.sendMessage(jid, { text: '❌ Você não está em um relacionamento para terminar.' }, { quoted: m });

            if (command.startsWith('terminar') && rel.status === 'casado') return sock.sendMessage(jid, { text: `Vocês são casados! Use \`${PREFIX}divorcio\`.` }, { quoted: m });
            if (command === 'divorcio' && rel.status === 'namorando') return sock.sendMessage(jid, { text: `Vocês estão namorando! Use \`${PREFIX}terminarnamoro\`.` }, { quoted: m });
            
            const partnerId = rel.partner === senderId ? rel.idPrincipal : rel.partner;
            delete data.casais[rel.idPrincipal];
            await writeData(data);
            
            const endMessage = rel.status === 'casado' ? 'se divorciaram' : 'terminaram o namoro';
            return sock.sendMessage(jid, { text: `💔 Fim de uma era... @${senderId.split('@')[0]} e @${partnerId.split('@')[0]} ${endMessage}.`, mentions: [senderId, partnerId] });
        }
        
        // --- LÓGICA PARA VER OS CASAIS ---
        if (command === 'casais') {
            const todosOsCasais = Object.entries(data.casais);
            if (todosOsCasais.length === 0) return sock.sendMessage(jid, { text: '💔 Não há casais formados por aqui.' });

            const casados = todosOsCasais.filter(([id, rel]) => rel.status === 'casado');
            const namorando = todosOsCasais.filter(([id, rel]) => rel.status === 'namorando');

            let message = '💞 *Painel de Relacionamentos* 💞\n';
            let mentions = [];

            if (casados.length > 0) {
                message += '\n--- 💍 *CASADOS* 💍 ---\n';
                casados.forEach(([p1, rel]) => {
                    const p2 = rel.partner;
                    message += `• @${p1.split('@')[0]} e @${p2.split('@')[0]}\n`;
                    mentions.push(p1, p2);
                });
            }

            if (namorando.length > 0) {
                message += '\n--- 💖 *NAMORANDO* 💖 ---\n';
                namorando.forEach(([p1, rel]) => {
                    const p2 = rel.partner;
                    message += `• @${p1.split('@')[0]} e @${p2.split('@')[0]}\n`;
                    mentions.push(p1, p2);
                });
            }
            
            return sock.sendMessage(jid, { text: message.trim(), mentions });
        }

    } catch (e) {
        console.error('Erro no sistema de relacionamento:', e);
        return sock.sendMessage(jid, { text: '❌ Ocorreu um erro no sistema de relacionamentos.' }, { quoted: m });
    }
};

// --- EXPORTAÇÃO CORRETA E COMPLETA ---
module.exports = {
    command,
    findUserRelationship
};